/**
 * @file gimbal_task.c
 * @brief ��̨��������
 */

#include "gimbal_task.h"
#include "gimbal_behaviour.h"
#include "cmsis_os.h"
#include "CAN_receive.h"
#include "main.h"
#include "INS_task.h"
#include "arm_math.h"
#include "math.h"
#include "detect_task.h"
#include "user_lib.h"
#include "chassis_task.h"
#include "usart.h"
#include "bsp_usart.h"
#include "USART_receive.h"
#include "bsp_led.h"

/*******************************************************************************
 * �궨��
 ******************************************************************************/
#define gimbal_total_pid_clear(gimbal_clear)                                               \
  {                                                                                        \
    gimbal_PID_clear(&(gimbal_clear)->gimbal_yaw_motor.gimbal_motor_absolute_angle_pid);   \
    gimbal_PID_clear(&(gimbal_clear)->gimbal_yaw_motor.gimbal_motor_relative_angle_pid);   \
    PID_clear(&(gimbal_clear)->gimbal_yaw_motor.gimbal_motor_gyro_pid);                    \
                                                                                           \
    gimbal_PID_clear(&(gimbal_clear)->gimbal_pitch_motor.gimbal_motor_absolute_angle_pid); \
    gimbal_PID_clear(&(gimbal_clear)->gimbal_pitch_motor.gimbal_motor_relative_angle_pid); \
    PID_clear(&(gimbal_clear)->gimbal_pitch_motor.gimbal_motor_gyro_pid);                  \
  }

/*******************************************************************************
 * ȫ�ֱ�������
 ******************************************************************************/
extern chassis_move_t chassis_move;
extern gimbal_behaviour_e gimbal_behaviour;
extern auto_shoot_t auto_shoot;

gimbal_control_t gimbal_control;

float gimbal_debug[10] = {0};
float gimbal_debug1[10] = {0};

static int16_t yaw_can_set_current = 0;
static int16_t pitch_can_set_current = 0;

/*******************************************************************************
 * ��̬��������
 ******************************************************************************/
static void gimbal_init(void);
static void gimbal_set_mode(void);
static void gimbal_feedback_update(void);
static float motor_ecd_to_angle_change(uint16_t ecd, uint16_t offset_ecd);
static void gimbal_set_control(void);
static void gimbal_control_loop(void);
static void gimbal_absolute_angle_limit(gimbal_motor_t *gimbal_motor, float add);
static void gimbal_relative_angle_limit(gimbal_motor_t *gimbal_motor, float add);
static void gimbal_motor_absolute_angle_control(gimbal_motor_t *gimbal_motor);
static void gimbal_motor_relative_angle_control(gimbal_motor_t *gimbal_motor);
static void gimbal_PID_init(gimbal_PID_t *pid, float kp, float ki, float kd, float maxout, float max_iout);
static float gimbal_PID_calc(gimbal_PID_t *pid, float get, float set, float error_delta);
static void gimbal_PID_clear(gimbal_PID_t *pid_clear);

/*******************************************************************************
 * ����ʵ��
 ******************************************************************************/

/**
 * @brief ��̨��������������
 * @param pvParameters RTOS�������
 */
void gimbal_task(void const *pvParameters)
{
  vTaskDelay(GIMBAL_TASK_INIT_TIME);

  // ��̨��ʼ��
  gimbal_init();

	
  // �ж��Ƿ��ϵ�ɹ�
  while (toe_is_error(YAW_GIMBAL_MOTOR_TOE) || toe_is_error(PITCH_GIMBAL_MOTOR_TOE))
  {
    vTaskDelay(GIMBAL_CONTROL_TIME);
    gimbal_feedback_update();
  }

  while (1)
  {
    
    // ������̨���ģʽ
    gimbal_set_mode();

    // ��̨��������
    gimbal_feedback_update();

    // ������̨����趨ֵ
    gimbal_set_control();

    // ��̨���PID����
    gimbal_control_loop();

    // ���ݵ���İ�װ���򣬵�����������
    #if YAW_TURN
      yaw_can_set_current = -gimbal_control.gimbal_yaw_motor.given_current;
    #else
      yaw_can_set_current = gimbal_control.gimbal_yaw_motor.given_current;
    #endif

    #if PITCH_TURN
      pitch_can_set_current = -gimbal_control.gimbal_pitch_motor.given_current + PITCH_CURRENT_FEEDFORWARD;//��������ǰ��
    #else
      pitch_can_set_current = gimbal_control.gimbal_pitch_motor.given_current + PITCH_CURRENT_FEEDFORWARD;//��������ǰ��
    #endif

    // ������Ƿ�����
    if (!(toe_is_error(YAW_GIMBAL_MOTOR_TOE) && toe_is_error(PITCH_GIMBAL_MOTOR_TOE)))
    {
      if (toe_is_error(DBUS_TOE))  // ң��������
      {
        CAN_cmd_gimbal(0, 0);
        // ֹͣʧ�ر���
        gimbal_control.gimbal_pitch_motor.absolute_angle_set = gimbal_control.gimbal_pitch_motor.absolute_angle;
        gimbal_control.gimbal_yaw_motor.absolute_angle_set = gimbal_control.gimbal_yaw_motor.absolute_angle;
      }
      else
      {
        CAN_cmd_gimbal(yaw_can_set_current,pitch_can_set_current);//pitch_can_set_current
      }
    }
    else
    {
      CAN_cmd_gimbal(0, 0);
    }
    send_vision_data();//���͸��Ӿ�������

    vTaskDelay(GIMBAL_CONTROL_TIME);
  }
}

/**
 * @brief ��ʼ����̨���ƽṹ�����
 */
static void gimbal_init(void)
{
  // ����ṹ���ȡ
  gimbal_control.gimbal_yaw_motor.gimbal_motor_measure = get_yaw_gimbal_motor_measure_point();
  gimbal_control.gimbal_pitch_motor.gimbal_motor_measure = get_pitch_gimbal_motor_measure_point();

  // ��ʼ�����ģʽ
  gimbal_control.gimbal_yaw_motor.gimbal_motor_mode = gimbal_control.gimbal_yaw_motor.last_gimbal_motor_mode = GIMBAL_MOTOR_RAW;
  gimbal_control.gimbal_pitch_motor.gimbal_motor_mode = gimbal_control.gimbal_pitch_motor.last_gimbal_motor_mode = GIMBAL_MOTOR_RAW;

  // ��ʼ����̨��������λ
  gimbal_control.gimbal_yaw_motor.offset_ecd = GIMBAL_YAW_OFFSET_ECD;
  gimbal_control.gimbal_yaw_motor.max_relative_angle = GIMBAL_YAW_MAX_ECD;
  gimbal_control.gimbal_yaw_motor.min_relative_angle = GIMBAL_YAW_MIN_ECD;

  gimbal_control.gimbal_pitch_motor.offset_ecd = GIMBAL_PITCH_OFFSET_ECD;
  gimbal_control.gimbal_pitch_motor.max_relative_angle = GIMBAL_PITCH_MAX_ECD;
  gimbal_control.gimbal_pitch_motor.min_relative_angle = GIMBAL_PITCH_MIN_ECD;

  // ��ʼ��yaw���PID
  gimbal_PID_init(&gimbal_control.gimbal_yaw_motor.gimbal_motor_absolute_angle_pid,
                  YAW_ABSOLUTE_ANGLE_KP, YAW_ABSOLUTE_ANGLE_KI, YAW_ABSOLUTE_ANGLE_KD,
                  YAW_ABSOLUTE_ANGLE_MAX_OUT, YAW_ABSOLUTE_ANGLE_MAX_IOUT);
  PID_init(&gimbal_control.gimbal_yaw_motor.gimbal_motor_gyro_pid,
           YAW_GYRO_KP, YAW_GYRO_KI, YAW_GYRO_KD,
           YAW_GYRO_MAX_OUT, YAW_GYRO_MAX_IOUT);

  // ��ʼ��pitch���PID
  gimbal_PID_init(&gimbal_control.gimbal_pitch_motor.gimbal_motor_absolute_angle_pid,
                  PITCH_ABSOLUTE_ANGLE_KP, PITCH_ABSOLUTE_ANGLE_KI, PITCH_ABSOLUTE_ANGLE_KD,
                  PITCH_ABSOLUTE_ANGLE_MAX_OUT, PITCH_ABSOLUTE_ANGLE_MAX_IOUT);
  PID_init(&gimbal_control.gimbal_pitch_motor.gimbal_motor_gyro_pid,
           PITCH_GYRO_KP, PITCH_GYRO_KI, PITCH_GYRO_KD,
           PITCH_GYRO_MAX_OUT, PITCH_GYRO_MAX_IOUT);

  // �������PID����
  gimbal_total_pid_clear(&gimbal_control);

  // ��������
  gimbal_feedback_update();

  // ��ʼ�����״̬
  gimbal_control.gimbal_yaw_motor.absolute_angle_set = gimbal_control.gimbal_yaw_motor.absolute_angle;
  gimbal_control.gimbal_yaw_motor.relative_angle_set = gimbal_control.gimbal_yaw_motor.relative_angle;
  gimbal_control.gimbal_yaw_motor.motor_gyro_set = gimbal_control.gimbal_yaw_motor.motor_gyro;

  gimbal_control.gimbal_pitch_motor.absolute_angle_set = gimbal_control.gimbal_pitch_motor.absolute_angle;
  gimbal_control.gimbal_pitch_motor.relative_angle_set = gimbal_control.gimbal_pitch_motor.relative_angle;
  gimbal_control.gimbal_pitch_motor.motor_gyro_set = gimbal_control.gimbal_pitch_motor.motor_gyro;
}

/**
 * @brief ������̨���ģʽ
 */
static void gimbal_set_mode(void)
{
  gimbal_behaviour_mode_set(&gimbal_control);
}

/**
 * @brief �������ݸ��£��������������ٶȡ��Ƕȡ����ת��
 */
static void gimbal_feedback_update(void)
{
  // ���ݵ����װ���򣬼���pitch��������Ƕ�
  #if PITCH_TURN
    gimbal_control.gimbal_pitch_motor.relative_angle = -motor_ecd_to_angle_change(
      gimbal_control.gimbal_pitch_motor.gimbal_motor_measure->ecd,
      gimbal_control.gimbal_pitch_motor.offset_ecd);
  #else
    gimbal_control.gimbal_pitch_motor.relative_angle = motor_ecd_to_angle_change(
      gimbal_control.gimbal_pitch_motor.gimbal_motor_measure->ecd,
      gimbal_control.gimbal_pitch_motor.offset_ecd);
  #endif

  gimbal_control.gimbal_pitch_motor.absolute_angle = INS_data.angle_pitch;
  gimbal_control.gimbal_pitch_motor.motor_gyro = INS_data.wx;

  // ���ݵ����װ���򣬼���yaw��������Ƕ�
  #if YAW_TURN
    gimbal_control.gimbal_yaw_motor.relative_angle = -motor_ecd_to_angle_change(
      gimbal_control.gimbal_yaw_motor.gimbal_motor_measure->ecd,
      gimbal_control.gimbal_yaw_motor.offset_ecd);
  #else
    gimbal_control.gimbal_yaw_motor.relative_angle = motor_ecd_to_angle_change(
      gimbal_control.gimbal_yaw_motor.gimbal_motor_measure->ecd,
      gimbal_control.gimbal_yaw_motor.offset_ecd);
  #endif

  gimbal_control.gimbal_yaw_motor.absolute_angle = INS_data.angle_yaw;
  // ����yaw����ٶȣ�����pitch�ǵ�Ӱ��
      // ԭʼ����ֵ
    float raw_gyro = arm_sin_f32(gimbal_control.gimbal_pitch_motor.relative_angle) * INS_data.wz
                   - arm_cos_f32(gimbal_control.gimbal_pitch_motor.relative_angle) * INS_data.wy;
    
    // һ�׵�ͨ�˲�ϵ�� (0.0~1.0)������ 0.2~0.5
    #define YAW_GYRO_FILTER_ALPHA  0.15f
    
    // ��̬����������һ���˲����
    static float yaw_gyro_filtered = 0.0f;
    static uint8_t filter_init_flag = 0;
    
    // �״γ�ʼ��ֱ�Ӹ�ֵ����������
    if (filter_init_flag == 0)
    {
        yaw_gyro_filtered = raw_gyro;
        filter_init_flag = 1;
    }
    else
    {
        // һ�׵�ͨ�˲�
        yaw_gyro_filtered = YAW_GYRO_FILTER_ALPHA * raw_gyro 
                          + (1.0f - YAW_GYRO_FILTER_ALPHA) * yaw_gyro_filtered;
    }
    
    gimbal_control.gimbal_yaw_motor.motor_gyro = yaw_gyro_filtered;
                                                
}

/**
 * @brief ����ecd��offset_ecd����Ƕȱ仯
 * @param ecd �����������ֵ
 * @param offset_ecd �����λ��������ֵ
 * @return �������Ƕȣ���λrad
 */
static float motor_ecd_to_angle_change(uint16_t ecd, uint16_t offset_ecd)
{
  int32_t relative_ecd = ecd - offset_ecd;

  // ��������������
  if (relative_ecd > 4096)
  {
    relative_ecd -= 8191;
  }
  else if (relative_ecd < -4096)
  {
    relative_ecd += 8191;
  }

  return relative_ecd * MOTOR_ECD_TO_RAD;
}

/**
 * @brief ������̨����趨ֵ
 */
static void gimbal_set_control(void)
{
  float add_yaw_angle = 0.0f;
  float add_pitch_angle = 0.0f;


 if (gimbal_behaviour == GIMBAL_AUTO)  // ���״̬
 {
   gimbal_behaviour_control_set(&add_yaw_angle, &add_pitch_angle, &gimbal_control);
   gimbal_control.gimbal_yaw_motor.absolute_angle_set = add_yaw_angle;
   gimbal_control.gimbal_pitch_motor.absolute_angle_set = add_pitch_angle;
 }
 else
 {
   gimbal_behaviour_control_set(&add_yaw_angle, &add_pitch_angle, &gimbal_control);
   gimbal_control.gimbal_yaw_motor.absolute_angle_set = gimbal_control.gimbal_yaw_motor.absolute_angle_set + add_yaw_angle;
   gimbal_absolute_angle_limit(&gimbal_control.gimbal_pitch_motor, add_pitch_angle);
 }
}

/**
 * @brief ���ԽǶ���λ����ֹ�������������GIMBAL_MOTOR_GYROģʽ��
 * @param gimbal_motor yaw�������pitch���
 * @param add ��Ҫ���ӵĽǶ�����
 */
static void gimbal_absolute_angle_limit(gimbal_motor_t *gimbal_motor, float add)
{
  float angle_set = 0.0f;
  if (gimbal_motor == NULL)
  {
    return;
  }

  angle_set = gimbal_motor->absolute_angle_set;
  gimbal_motor->absolute_angle_set = rad_format(angle_set + add);
  if (gimbal_motor->absolute_angle_set > gimbal_motor->max_relative_angle)
  {
    gimbal_motor->absolute_angle_set = gimbal_motor->max_relative_angle;
  }
  else if (gimbal_motor->absolute_angle_set < gimbal_motor->min_relative_angle)
  {
    gimbal_motor->absolute_angle_set = gimbal_motor->min_relative_angle;
  }
}

/**
 * @brief ��ԽǶ���λ����ֹ�������������GIMBAL_MOTOR_ENCONDEģʽ��
 * @param gimbal_motor yaw�������pitch���
 * @param add ��Ҫ���ӵĽǶ�����
 */
static void gimbal_relative_angle_limit(gimbal_motor_t *gimbal_motor, float add)
{
  if (gimbal_motor == NULL)
  {
    return;
  }

  gimbal_motor->relative_angle_set += add;

  // �Ƕ��޷�
  if (gimbal_motor->relative_angle_set > gimbal_motor->max_relative_angle)
  {
    gimbal_motor->relative_angle_set = gimbal_motor->max_relative_angle;
  }
  else if (gimbal_motor->relative_angle_set < gimbal_motor->min_relative_angle)
  {
    gimbal_motor->relative_angle_set = gimbal_motor->min_relative_angle;
  }
}

/**
 * @brief ִ��ѭ����������
 */
static void gimbal_control_loop(void)
{
  // ���ݵ���ģʽѡ��ͬ��PID����
  if (chassis_move.chassis_mode == CHASSIS_TOP)  // С����ģʽ
  {
    gimbal_PID_init(&gimbal_control.gimbal_yaw_motor.gimbal_motor_absolute_angle_pid,
                    YAW_TOP_ABSOLUTE_ANGLE_KP, YAW_TOP_ABSOLUTE_ANGLE_KI, YAW_TOP_ABSOLUTE_ANGLE_KD,
                    YAW_TOP_ABSOLUTE_ANGLE_MAX_OUT, YAW_TOP_ABSOLUTE_ANGLE_MAX_IOUT);
    PID_init(&gimbal_control.gimbal_yaw_motor.gimbal_motor_gyro_pid,
             YAW_TOP_GYRO_KP, YAW_TOP_GYRO_KI, YAW_TOP_GYRO_KD,
             YAW_TOP_GYRO_MAX_OUT, YAW_TOP_GYRO_MAX_IOUT);
  }
  else  // ����ģʽ
  {
    gimbal_PID_init(&gimbal_control.gimbal_yaw_motor.gimbal_motor_absolute_angle_pid,
                    YAW_ABSOLUTE_ANGLE_KP, YAW_ABSOLUTE_ANGLE_KI, YAW_ABSOLUTE_ANGLE_KD,
                    YAW_ABSOLUTE_ANGLE_MAX_OUT, YAW_ABSOLUTE_ANGLE_MAX_IOUT);
    PID_init(&gimbal_control.gimbal_yaw_motor.gimbal_motor_gyro_pid,
             YAW_GYRO_KP, YAW_GYRO_KI, YAW_GYRO_KD,
             YAW_GYRO_MAX_OUT, YAW_GYRO_MAX_IOUT);
  }

  // yaw�����
  if (gimbal_control.gimbal_yaw_motor.gimbal_motor_mode == GIMBAL_MOTOR_RAW)
  {
    gimbal_control.gimbal_yaw_motor.given_current = 0;
  }
  else
  {
    gimbal_motor_absolute_angle_control(&gimbal_control.gimbal_yaw_motor);
  }

  // pitch�����
  if (gimbal_control.gimbal_pitch_motor.gimbal_motor_mode == GIMBAL_MOTOR_RAW)
  {
    gimbal_control.gimbal_pitch_motor.given_current = 0;
  }
  else
  {
    gimbal_motor_absolute_angle_control(&gimbal_control.gimbal_pitch_motor);
  }
}

/**
 * @brief ��̨������ԽǶȿ��ƣ�ʹ�������Ǻ;��ԽǶȣ�
 * @param gimbal_motor yaw�������pitch���
 */
static void gimbal_motor_absolute_angle_control(gimbal_motor_t *gimbal_motor)
{
  if (gimbal_motor == NULL)
  {
    return;
  }

    // �ǶȻ�����Ŀ����ٶ�
    gimbal_motor->motor_gyro_set = gimbal_PID_calc(&gimbal_motor->gimbal_motor_absolute_angle_pid,
                                                  gimbal_motor->absolute_angle,
                                                  gimbal_motor->absolute_angle_set,
                                                  gimbal_motor->motor_gyro);

  // �ٶȻ�����Ŀ�����
  gimbal_motor->current_set = PID_calc(&gimbal_motor->gimbal_motor_gyro_pid,
                                       gimbal_motor->motor_gyro,
                                       gimbal_motor->motor_gyro_set);

  // �趨ֵ��ֵ
  gimbal_motor->given_current = (int16_t)(gimbal_motor->current_set);
}

/**
 * @brief ��̨�����ԽǶȿ��ƣ�ʹ�ñ�������ԽǶȣ�
 * @param gimbal_motor yaw�������pitch���
 */
static void gimbal_motor_relative_angle_control(gimbal_motor_t *gimbal_motor)
{
  if (gimbal_motor == NULL)
  {
    return;
  }

  // �ǶȻ�����Ŀ����ٶ�
  gimbal_motor->motor_gyro_set = gimbal_PID_calc(&gimbal_motor->gimbal_motor_relative_angle_pid,
                                                 gimbal_motor->relative_angle,
                                                 gimbal_motor->relative_angle_set,
                                                 gimbal_motor->motor_gyro);

  // �ٶȻ�����Ŀ�����
  gimbal_motor->current_set = PID_calc(&gimbal_motor->gimbal_motor_gyro_pid,
                                       gimbal_motor->motor_gyro,
                                       gimbal_motor->motor_gyro_set);

  // �趨ֵ��ֵ
  gimbal_motor->given_current = (int16_t)(gimbal_motor->current_set);
}

/**
 * @brief ��̨PID��ʼ������
 * @param pid PID�ṹ��ָ��
 * @param kp ����ϵ��
 * @param ki ����ϵ��
 * @param kd ΢��ϵ��
 * @param maxout ������
 * @param max_iout ���������
 */
static void gimbal_PID_init(gimbal_PID_t *pid, float kp, float ki, float kd, float maxout, float max_iout)
{
  if (pid == NULL)
  {
    return;
  }

  pid->kp = kp;
  pid->ki = ki;
  pid->kd = kd;
  pid->err = 0.0f;
  pid->get = 0.0f;
  pid->max_iout = max_iout;
  pid->max_out = maxout;
}

/**
 * @brief ��̨PID���㺯��
 * @param pid PID�ṹ��ָ��
 * @param get ��ǰֵ
 * @param set �趨ֵ
 * @param error_delta ���仯��������΢����
 * @return �������
 */
static float gimbal_PID_calc(gimbal_PID_t *pid, float get, float set, float error_delta)
{
  float err;

  if (pid == NULL)
  {
    return 0.0f;
  }

  pid->get = get;
  pid->set = set;
  err = set - get;
  pid->err = rad_format(err);

  // PID����
  pid->Pout = pid->kp * pid->err;
  pid->Iout += pid->ki * pid->err;
  pid->Dout = pid->kd * error_delta;

  // �޷�
  abs_limit(&pid->Iout, pid->max_iout);
  pid->out = pid->Pout + pid->Iout + pid->Dout;
  abs_limit(&pid->out, pid->max_out);

  return pid->out;
}

/**
 * @brief �����̨PID�ṹ�������
 * @param gimbal_pid_clear PID�ṹ��ָ��
 */
static void gimbal_PID_clear(gimbal_PID_t *gimbal_pid_clear)
{
  if (gimbal_pid_clear == NULL)
  {
    return;
  }

  gimbal_pid_clear->err = gimbal_pid_clear->set = gimbal_pid_clear->get = 0.0f;
  gimbal_pid_clear->out = gimbal_pid_clear->Pout = gimbal_pid_clear->Iout = gimbal_pid_clear->Dout = 0.0f;
}

/*******************************************************************************
 * ����ӿں���
 ******************************************************************************/

/**
 * @brief ��ȡyaw����ṹ��ָ��
 * @return yaw����ṹ��ָ��
 */
const gimbal_motor_t *get_yaw_motor_point(void)
{
  return &gimbal_control.gimbal_yaw_motor;
}

/**
 * @brief ��ȡpitch����ṹ��ָ��
 * @return pitch����ṹ��ָ��
 */
const gimbal_motor_t *get_pitch_motor_point(void)
{
  return &gimbal_control.gimbal_pitch_motor;
}
