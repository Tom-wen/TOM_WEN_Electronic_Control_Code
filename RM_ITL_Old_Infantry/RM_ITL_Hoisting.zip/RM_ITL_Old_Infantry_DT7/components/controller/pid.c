#include "PID.h"
#include "chassis_task.h"

/**************************����PID���˹��㱣����û���κ�����**********************************/

int Limit_Min_Max(int value,int min,int max);

/**
 * @brief PID�����ʼ��
 * @param PID PID����
 * @param kp 
 * @param ki 
 * @param kd 
 * @param i_max 
 * @param out_max 
 */
void PID_Init(PID_struct_t *PID,
              float kp,
              float ki,
              float kd,
              float i_max,
              float out_max)//PID��ʼ������
{
  PID->kp      = kp;
  PID->ki      = ki;
  PID->kd      = kd;
  PID->i_max   = i_max;//�����޷�
  PID->out_max = out_max;//����޷�
}

 void PID_Protect_Angle(PID_struct_t *pid)
{
	if(pid->ref - pid->fdb > 4096)
	{
		pid->fdb+=8190;
	}
	else if(pid->ref - pid->fdb < -4096)
	{
		pid->fdb-=8190;
	}
}

 void PID_Protect_Ink(PID_struct_t *pid)
{
	if(pid->ref - pid->fdb > 180)
	{
		pid->fdb+=360;
	}
	else if(pid->ref - pid->fdb < -180)
	{
		pid->fdb-=360;
	}
}

float PID_Calc_Angle(PID_struct_t *PID, float ref, float fdb)//PID���㺯����Ŀ�꣬ʵ�ʣ�
{
  PID->ref = ref;
  PID->fdb = fdb;

	PID_Protect_Angle(PID);//���㱣��

  PID->err[1] = PID->err[0];
  PID->err[0] = PID->ref - PID->fdb;
  
  PID->p_out  = PID->kp * PID->err[0];
  PID->i_out += PID->ki * PID->err[0];
  PID->d_out  = PID->kd * (PID->err[0] - PID->err[1]);
  PID->i_out=Limit_Min_Max(PID->i_out, -PID->i_max, PID->i_max);
  
  PID->output = PID->p_out + PID->i_out + PID->d_out;
  PID->output=Limit_Min_Max(PID->output, -PID->out_max, PID->out_max);
  return PID->output;
}

float PID_Calc_Ink(PID_struct_t *PID, float ref, float fdb)//PID���㺯����Ŀ�꣬ʵ�ʣ�
{
  PID->ref = ref;
  PID->fdb = fdb;

	PID_Protect_Ink(PID);//���㱣��

  PID->err[1] = PID->err[0];
  PID->err[0] = PID->ref - PID->fdb;
  
  PID->p_out  = PID->kp * PID->err[0];
  PID->i_out += PID->ki * PID->err[0];
  PID->d_out  = PID->kd * (PID->err[0] - PID->err[1]);
  PID->i_out=Limit_Min_Max(PID->i_out, -PID->i_max, PID->i_max);
  
  PID->output = PID->p_out + PID->i_out + PID->d_out;
  PID->output=Limit_Min_Max(PID->output, -PID->out_max, PID->out_max);
  return PID->output;
}

float PID_Calc_Speed(PID_struct_t *PID, float ref, float fdb)//PID���㺯����Ŀ�꣬ʵ�ʣ�
{
  PID->ref = ref;
  PID->fdb = fdb;

  PID->err[1] = PID->err[0];
  PID->err[0] = PID->ref - PID->fdb;

  PID->p_out  = PID->kp * PID->err[0];
  PID->i_out += PID->ki * PID->err[0];
  PID->d_out  = PID->kd * (PID->err[0] - PID->err[1]);
  PID->i_out=Limit_Min_Max(PID->i_out, -PID->i_max, PID->i_max);
  
  PID->output = PID->p_out + PID->i_out + PID->d_out;
  PID->output=Limit_Min_Max(PID->output, -PID->out_max, PID->out_max);
  return PID->output;
}

/**
 * @brief ����һ���������� value ��ָ������Сֵ min �����ֵ max ֮��
 * @param value ����ֵ
 * @param min ��Сֵ
 * @param max ���ֵ
 * @return 
 */
int Limit_Min_Max(int value,int min,int max)
{
	if(value<min)
		return min;
	else if(value>max)
		return max;
	else return value;
}

#define LimitMax(input, max)   \
	{                          \
		if (input > max)       \
		{                      \
			input = max;       \
		}                      \
		else if (input < -max) \
		{                      \
			input = -max;      \
		}                      \
	}

/**
  * @brief          pid�ṹ���ݳ�ʼ��
  * @param[out]     pid: PID�ṹ����ָ��
  * @param[in]      kd
  * @param[in]      ki
  * @param[in]      kd
  * @param[in]      max_out: pid������
  * @param[in]      max_iout: pid���������
 */
void PID_init(pid_type_def *pid, float Kp, float Ki, float Kd, float max_out, float max_iout)
{
	if (pid == NULL)
	{
		return;
	}
	pid->Kp = Kp;
	pid->Ki = Ki;
	pid->Kd = Kd;
	pid->max_out = max_out;
	pid->max_iout = max_iout;
	pid->Dbuf[0] = pid->Dbuf[1] = pid->Dbuf[2] = 0.0f;
	pid->error[0] = pid->error[1] = pid->error[2] = pid->Pout = pid->Iout = pid->Dout = pid->out = 0.0f;
}


/**
 * @brief          pid����
 * @param[out]     pid: PID�ṹ����ָ��
 * @param[in]      ref: ��������
 * @param[in]      set: �趨ֵ
 * @return         pid���
 */
float PID_calc(pid_type_def *pid, float ref, float set)
{
	if (pid == NULL)
	{
		return 0.0f;
	}

	pid->error[2] = pid->error[1];
	pid->error[1] = pid->error[0];
	pid->set = set;
	pid->fdb = ref;
	pid->error[0] = set - ref;

	pid->Pout = pid->Kp * pid->error[0];
	pid->Iout += pid->Ki * pid->error[0];
	pid->Dbuf[2] = pid->Dbuf[1];
	pid->Dbuf[1] = pid->Dbuf[0];
	pid->Dbuf[0] = (pid->error[0] - pid->error[1]);
	pid->Dout = pid->Kd * pid->Dbuf[0];
	LimitMax(pid->Iout, pid->max_iout);
	pid->out = pid->Pout + pid->Iout + pid->Dout;
	LimitMax(pid->out, pid->max_out);

	return pid->out;
}



float PID_calc_chassis(pid_type_def *pid, float ref, float set)
{
	if (pid == NULL)
	{
		return 0.0f;
	}

	pid->error[2] = pid->error[1];
	pid->error[1] = pid->error[0];
	pid->set = set;
	pid->fdb = ref;
	pid->error[0] = set - ref;

	pid->Pout = pid->Kp * pid->error[0];
	pid->Iout += pid->Ki * pid->error[0];
	pid->Dbuf[2] = pid->Dbuf[1];
	pid->Dbuf[1] = pid->Dbuf[0];
	pid->Dbuf[0] = (pid->error[0] - pid->error[1]);
	pid->Dout = pid->Kd * pid->Dbuf[0];
	LimitMax(pid->Iout, pid->max_iout);
	pid->out = pid->Pout + pid->Iout + pid->Dout;
	LimitMax(pid->out, CHASSIS_MOTOR_SPEED_MAX_OUT);

	return pid->out;
}


/**
  * @brief          pid ������
  * @param[out]     pid: PID�ṹ����ָ��
  * @retval         none
  */
void PID_clear(pid_type_def *pid)
{
    if (pid == NULL)
    {
        return;
    }

    pid->error[0] = pid->error[1] = pid->error[2] = 0.0f;
    pid->Dbuf[0] = pid->Dbuf[1] = pid->Dbuf[2] = 0.0f;
    pid->out = pid->Pout = pid->Iout = pid->Dout = 0.0f;
    pid->fdb = pid->set = 0.0f;
}
short PID_deadline_limit( short *input, float deadline)
{
if ((*input)<(deadline)&&(*input)>(-1*deadline))                                             
        {                                                
            (*input) = 0;                                
        }   
}

