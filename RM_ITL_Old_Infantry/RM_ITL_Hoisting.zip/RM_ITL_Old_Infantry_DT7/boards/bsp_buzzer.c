#include "bsp_buzzer.h"

void buzzer_init() 
{ 
    HAL_TIM_PWM_Start(&htim12, TIM_CHANNEL_2);

    htim12.Instance->ARR = 40000 - 1;       
    htim12.Instance->CCR2 = htim12.Instance->ARR / 2;
    HAL_Delay(250);  
    
    htim12.Instance->ARR = 28000 - 1;       
    htim12.Instance->CCR2 = htim12.Instance->ARR / 2;
    HAL_Delay(250);      

    htim12.Instance->ARR = 21000 - 1;       
    htim12.Instance->CCR2 = htim12.Instance->ARR / 2;
    HAL_Delay(300);  

    htim12.Instance->CCR2 = 0;
}

void buzzer_warning()
{
    while(1)
    {
        htim12.Instance->CCR2 =500;
        HAL_Delay(300);
        htim12.Instance->CCR2 =0;
        HAL_Delay(300);
    }
}

void buzzer_on()
{
    htim12.Instance->CCR2 =500;
}

void buzzer_off()
{
    htim12.Instance->CCR2 =0;
}









// ==================== 10MHz ����ʱ�Ӻ궨�� ====================
// ���� TIM12 ����ʱ�� = 10MHz (10,000,000 Hz)
// ���㹫ʽ: ARR = 10000000 / Ƶ�� - 1

// С����ʹ�õ����� (C5-A5)
#define NOTE_C5 19110  // 523.25 Hz  (1)
#define NOTE_D5 17026  // 587.33 Hz  (2)
#define NOTE_E5 15171  // 659.25 Hz  (3)
#define NOTE_F5 14320  // 698.46 Hz  (4)
#define NOTE_G5 12754  // 783.99 Hz  (5)
#define NOTE_A5 11363  // 880.00 Hz  (6)

// ��ֹ��
#define NOTE_REST 0

// ����ʱ������ (ms)
#define BEAT_4TH   400  // �ķ����� (һ ��)
#define BEAT_2ND   800  // �������� (�� -)

// ==================== �������� ====================

/**
 * @brief ����һ������
 * @param arr_value  ARRֵ�������궨�壩
 * @param duration_ms ʱ����ms��
 */
void play_note(uint32_t arr_value, uint32_t duration_ms)
{
    if (arr_value == 0) {
        // ��ֹ��
        buzzer_off();
        HAL_Delay(duration_ms);
        return;
    }
    
    // ����Ƶ�� (ARR)
    htim12.Instance->ARR = arr_value;
    
    // ���� 50% ռ�ձ� (��������)
    htim12.Instance->CCR2 = arr_value / 2;
    
    // ����ָ��ʱ��
    HAL_Delay(duration_ms);
    
    // ������̼�� (ʹ���ɸ�����)
    buzzer_off();
    HAL_Delay(30);
}

// ==================== С���� ====================

/**
 * @brief ���š�С���ǡ�
 * @note ���� 10MHz ����ʱ��
 */
void buzzer_play_twinkle_star(void)
{
    // ȷ�� PWM ������
    HAL_TIM_PWM_Start(&htim12, TIM_CHANNEL_2);
    
    // ========== ��һ�� ==========
    // 1  1  5  5  |  6  6  5  -
    play_note(NOTE_C5, BEAT_4TH);  // 1
    play_note(NOTE_C5, BEAT_4TH);  // 1
    play_note(NOTE_G5, BEAT_4TH);  // 5
    play_note(NOTE_G5, BEAT_4TH);  // 5
    play_note(NOTE_A5, BEAT_4TH);  // 6
    play_note(NOTE_A5, BEAT_4TH);  // 6
    play_note(NOTE_G5, BEAT_2ND);  // 5 -
    
    // 4  4  3  3  |  2  2  1  -
    play_note(NOTE_F5, BEAT_4TH);  // 4
    play_note(NOTE_F5, BEAT_4TH);  // 4
    play_note(NOTE_E5, BEAT_4TH);  // 3
    play_note(NOTE_E5, BEAT_4TH);  // 3
    play_note(NOTE_D5, BEAT_4TH);  // 2
    play_note(NOTE_D5, BEAT_4TH);  // 2
    play_note(NOTE_C5, BEAT_2ND);  // 1 -
    
    // ========== �ڶ��� ==========
    // 5  5  4  4  |  3  3  2  -
    play_note(NOTE_G5, BEAT_4TH);  // 5
    play_note(NOTE_G5, BEAT_4TH);  // 5
    play_note(NOTE_F5, BEAT_4TH);  // 4
    play_note(NOTE_F5, BEAT_4TH);  // 4
    play_note(NOTE_E5, BEAT_4TH);  // 3
    play_note(NOTE_E5, BEAT_4TH);  // 3
    play_note(NOTE_D5, BEAT_2ND);  // 2 -
    
    // 5  5  4  4  |  3  3  2  -
    play_note(NOTE_G5, BEAT_4TH);  // 5
    play_note(NOTE_G5, BEAT_4TH);  // 5
    play_note(NOTE_F5, BEAT_4TH);  // 4
    play_note(NOTE_F5, BEAT_4TH);  // 4
    play_note(NOTE_E5, BEAT_4TH);  // 3
    play_note(NOTE_E5, BEAT_4TH);  // 3
    play_note(NOTE_D5, BEAT_2ND);  // 2 -
    
    // ========== ������ (�ظ���һ��) ==========
    // 1  1  5  5  |  6  6  5  -
    play_note(NOTE_C5, BEAT_4TH);  // 1
    play_note(NOTE_C5, BEAT_4TH);  // 1
    play_note(NOTE_G5, BEAT_4TH);  // 5
    play_note(NOTE_G5, BEAT_4TH);  // 5
    play_note(NOTE_A5, BEAT_4TH);  // 6
    play_note(NOTE_A5, BEAT_4TH);  // 6
    play_note(NOTE_G5, BEAT_2ND);  // 5 -
    
    // 4  4  3  3  |  2  2  1  -
    play_note(NOTE_F5, BEAT_4TH);  // 4
    play_note(NOTE_F5, BEAT_4TH);  // 4
    play_note(NOTE_E5, BEAT_4TH);  // 3
    play_note(NOTE_E5, BEAT_4TH);  // 3
    play_note(NOTE_D5, BEAT_4TH);  // 2
    play_note(NOTE_D5, BEAT_4TH);  // 2
    play_note(NOTE_C5, BEAT_2ND);  // 1 -
    
    // ���رշ�����
    buzzer_off();
}